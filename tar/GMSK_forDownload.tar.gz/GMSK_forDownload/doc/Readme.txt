GMSK transceiver is a module in charge of modulating the bit stream into 
baseband time discrete signal and demodulating the baseband signal to bit 
stream in the inverse direction. This transceiver is used by base station 
in GSM system, for it has only implement two types of burst��s receiver, the 
normal burst and access burst. However, all the necessary parts to extend 
the function to other types of burst are there. The only work to do is to 
generate the corresponding standard mid-ample baseband signal and add them 
to the gmskDemodulation module. Thanks to the patent published by Suwon-Si 
and Kyunggi of Samsung Electronics Co., Ltd.

To make the transmitter work, a data source should be connected to 
gmskModulation and further the baseband data bus of gmskModulation 
connected to DA convertor. While demodulation module get baseband signal 
from AD convertor and than output corresponding 
