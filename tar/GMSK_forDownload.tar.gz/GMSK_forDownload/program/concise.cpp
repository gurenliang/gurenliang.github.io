#include <stdio.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>

#define MAC_ADD_FPGA 0x00,0x00,0x00,0x00,0x00,0x01
#define MAC_ADD_PC   0x00,0x00,0x00,0x00,0x00,0x02

#define num 8

const unsigned char sndhead[]={MAC_ADD_FPGA, MAC_ADD_PC, 0x00, 0x00};
const unsigned char mac_fpga[]={MAC_ADD_FPGA};

void printdata(char* str, unsigned char* buf1, int size);
void frameGen(unsigned char* buf);
void burstGen(unsigned char* buf, int type);
void printBit(char* str, unsigned char* buf, int startBit, int len, int unit);

int main(){
	int error_cnt=0;
	int frame_cnt=1000;
	long int frame_number, fn1=0, fn2=0, fn3=0;

	unsigned int sndlen=14+3+((unsigned int)(148*num/8));
	unsigned int datasndlen= ((unsigned int)(148*num/8));
	unsigned int rcvlen=14+3+((unsigned int)(160*num/8));
	
	unsigned char sndbuf[sndlen];	//6+6+2+3+8*148
	unsigned char rcvbuf[rcvlen];	//actually is 96 = 6+6+2+3+[4*156.25]+1

	unsigned char* sndlentype = sndbuf + 12;
	unsigned char* sndframenumber = sndbuf + 14;
	unsigned char* snddata = sndbuf + 17;

	unsigned char* rcvlentype = rcvbuf + 12;	
	unsigned char* rcvframenumber = rcvbuf + 14;
	unsigned char* rcvdata = rcvbuf + 17;

	unsigned char* temppoint;

	int mSocketFD;
	struct ifreq ifstruct;
	struct sockaddr_ll sll;
	int retval = 0;

	struct timeval testtime;
	long int usec2, usec1;

	memcpy(sndbuf, sndhead, 14);

	// create
	mSocketFD = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if (mSocketFD < 0){
		perror("socket()");
	}

	//struct ifreq ifstruct;
	strcpy(ifstruct.ifr_name, "eth0");
	retval = ioctl(mSocketFD, SIOCGIFINDEX, &ifstruct);
	if(retval == -1){
		perror("RAWSocket::open(): ioctl()");
	}

	//struct sockaddr_ll sll;
	memset(&sll, 0, sizeof(sll));
	sll.sll_family = AF_PACKET;
	sll.sll_protocol = htons(ETH_P_ALL);
	sll.sll_ifindex = ifstruct.ifr_ifindex;

	// bind
	retval = bind(mSocketFD, (struct sockaddr *)&sll, sizeof(sll));
	if(retval == -1)
	{
		perror("RAWSocket::open(): bind()");
	}

	// set recive buffer size
	//int rcvbuflen = BUFFER_SIZE;
	int rcvbuflen = 4000;//442;//221;
	retval = setsockopt(mSocketFD, SOL_SOCKET, SO_RCVBUF, (char *)&rcvbuflen, sizeof(int));
	if (retval == -1)
	{
		perror("RAWSocket::read(): setsockopt()");
	}
	// set send buffer size
	//int sndbuflen = BUFFER_SIZE;
	int sndbuflen = 15000;
	retval = setsockopt(mSocketFD, SOL_SOCKET, SO_SNDBUF, (char *)&sndbuflen, sizeof(int));
	if (retval == -1)
	{
		perror("RAWSocket::read(): setsockopt()");
	}

	frame_number = 0;
	sndframenumber[0] = frame_number;
	sndframenumber[1] = frame_number >> 8;
	sndframenumber[2] = frame_number >> 16;
	
	temppoint=snddata;
	frameGen(snddata);
	//printdata("The ethernet frame to send",sndbuf,sndlen);
	printBit("original data format", snddata, 0, 148*8, 148);
	
	//exit(0);
	
	retval = send(mSocketFD, sndbuf, sndlen, 0);
	if (retval < 0)
	{
		perror("sendto()");
	}

	while( (frame_cnt>=0)&&( (retval = recv(mSocketFD, (void*)rcvbuf, rcvlen, 0)) >=0) ) {

		printf("received data length: %d\n", retval);
		
		if (retval < 42){
			perror("recvfrom():");
			break;
		}

		if (memcmp(mac_fpga, rcvbuf+6, 6) == 0)
		{
			fn3 = fn2;	fn2 = fn1;
			fn1 = (long int)(rcvbuf[16]<<16) + (rcvbuf[15]<<8) + rcvbuf[14];
			long int temp;
		
			frame_number ++;  frame_cnt--;
			sndframenumber[0] = frame_number;
			sndframenumber[1] = frame_number >> 8;
			sndframenumber[2] = frame_number >> 16;
		
			gettimeofday(&testtime, NULL);	
			usec2=usec1;				
			usec1=testtime.tv_usec;

			temp=(usec1+1000000-usec2)%1000000;
			printf("%5ld\t%5ld\t%5ld\t%ld", temp, fn2, fn1, fn1&0x0f);

			if( fn2+1 != fn1){
				printf("\t%5ld\t*\n",frame_number);	
				error_cnt++;
			}else{
				printf("\t%5ld\n", frame_number);
			}
				//printdata(NULL, rcvbuf,rcvlen);
				printBit("received", rcvdata, 0, 160*8, 160);
				//exit(0);
			//}

			retval = send(mSocketFD, sndbuf, sndlen, 0);
			if (retval < 0) perror("sendto()");
		}else printdata("wrong mac of fpga", rcvbuf+6, 6);
		
	}
	printf("the total number of wrong frames is:%d\n", error_cnt);	
}


void printdata(char* str, unsigned char* buf1, int size)
{
	unsigned char temp=0;
	unsigned int i;
	unsigned char* buf=buf1;
	
	i=0;
	printf("%s:\n",str);
	if(size==0){
		printf("\t\tNot data!\n");
	}else{
		printf("\t\t");
		while((size>0)&&(i<512)){
			printf(" %02x",*buf);
			temp++; size--; buf++; i++;
			if(!(temp & 3)){
				if(temp==16){
					temp=0;
					printf("\n\t\t");
				}else printf(" ");
			}
		}
		printf("\n");
	}
	printf("\n");
}

void frameGen(unsigned char* buf){
	int i;
	unsigned char buffer[148*8];
	for(i=0; i<8; i++)
		burstGen(&(buffer[i*148]),rand());
	for(i=0; i<148; i++){
		buf[i]= (buffer[i*8  ]   )+(buffer[i*8+1]<<1)+(buffer[i*8+2]<<2)+(buffer[i*8+3]<<3);
		buf[i]+=(buffer[i*8+4]<<4)+(buffer[i*8+5]<<5)+(buffer[i*8+6]<<6)+(buffer[i*8+7]<<7);
	}
	//printdata("frameGen", buf, 148);
}

unsigned char normal[26]={0,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,0,1,0,1,1,1};
unsigned char access[49]={0,0,1,1,1,0,1,0,0,1,0,0,1,0,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,0,0,1,1,0,1,0,1,0,1,0,0,0,1,1,1,1,0,0,0};

void burstGen(unsigned char* buf, int type){
	int i;
	switch(type%2){
	case 0:
		buf[0]=0; buf[1]=0; buf[2]=0;
		for(i=3; i<148; i++){
			if((i>=61)&&(i<87)){
				buf[i]=normal[i-61];
			}else buf[i]=rand()%2;
		}
		break;
	case 1:
		for(i=0; i<148; i++){
			if(i<49){
				buf[i]=access[i];
			}else buf[i]=rand()%2;
		}
	}
	for(i=0; i<148; i++) printf("%d", buf[i]);
	printf("\n");
}

void printBit(char* str, unsigned char* buf, int startBit, int len, int unit){
	unsigned char tmp[len];
	unsigned char buffer[20];
	unsigned short a;
	int	i=0, j=0, idx; 
	
	printf("%s:\n",str);
	
	a=buf[0]>>startBit;
	for(i=0; i<len; i++){
		if(i%8==0) a+=((unsigned short)buf[i/8+1])<<(8-startBit);
		tmp[i]=a%2;
		//if(i>0) tmp[i]=tmp[i-1]^(a%2);
		//else tmp[i]=a%2;
		a=a/2;
	}
	
	j=0;
	while(j<len){
		idx=0;
		switch(unit){
		case 148:
			for(i=j;i<j+unit;i++){
				if((i-j)%8==0) buffer[idx]=tmp[i];
				else buffer[idx]=buffer[idx]*2+(tmp[i]);
				if((i-j)%8==7) idx++;
			}
			for(i=0;i<(unit+7)/8;i++)
				printf("%02x", buffer[i]);
			printf("\n");
			/*
			idx=0;
			for(i=j;i<j+unit-1;i++){
				if((i-j)%8==0) buffer[idx]=tmp[i]^tmp[i+1];
				else buffer[idx]=buffer[idx]*2+(tmp[i]^tmp[i+1]);
				if((i-j)%8==7) idx++;
			}
			for(i=0;i<(unit+7-1)/8;i++)
				printf("%02x", buffer[i]);
			printf("\n");
			*/
			j+=unit;
			break;
		case 160:
			for(i=j;i<j+unit;i++){
				if((i-j)%8==0) buffer[idx]=((i-j)<12)? tmp[11-i+j+j]:tmp[i];
				else buffer[idx]=buffer[idx]*2+(((i-j)<12)? tmp[11-i+j+j]:tmp[i]);
				if((i-j)%8==7) idx++;
			}
			for(i=0;i<(unit+7)/8;i++){
				if(i==0)
					printf("%03d ", buffer[0]/2);
				else if(i==1){
					printf("%02d ", ((buffer[0]%2)*16+(buffer[1]>>4)));
					printf("%01x", buffer[1]&0x0f);
				}else
					printf("%02x", buffer[i]);
			}
			printf("\n");
			/*
			idx=0;
			for(i=j;i<j+unit-1;i++){
				if((i-j)%8==0) buffer[idx]=(((i-j)<12)? tmp[i]:(tmp[i]^tmp[i+1]));
				else buffer[idx]=buffer[idx]*2+(((i-j)<12)? tmp[i]:(tmp[i]^tmp[i+1]));
				if((i-j)%8==7) idx++;
			}
			for(i=0;i<(unit+7-1)/8;i++)
				printf("%02x", buffer[i]);
			printf("\n");*/
			j+=unit;
		}
	}
}
	
