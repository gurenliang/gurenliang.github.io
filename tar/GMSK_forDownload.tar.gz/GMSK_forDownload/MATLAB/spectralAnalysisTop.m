function [S1, S2] = spectralAnalysisTop( data, len, fs)
%UNTITLED1 Summary of this function goes here
%  Detailed explanation goes here
f1=figure;
f2=figure;
S1=spectralAnalysis1(data(:,[3:14]),len,fs,f1,f2,1);
S2=spectralAnalysis1(data(:,[16:27]),len,fs,f1,f2,2);