close all;
%Begin the program to test whether the generated ROM Data is correct
N=30;
d=binornd(1,0.5,1,N+1);
diffCode=(xor(d(1:N),d(2:N+1)))  %size of alpha is 1*N
figure; hold on;
phit0=0;
for i=1:N-4
    index=[diffCode(i+4:-1:i+3),diffCode(i+1:-1:i)];
    if(diffCode(i+2)==1)
        romIndex=binvec2dec(1-index);
        romOut=4096-[0,phiRom(romIndex+1,:)];
    else
        romIndex=binvec2dec(index);
        romOut=[0,phiRom(romIndex+1,:)];
    end
    plot(((i-1)*16:i*16), sin(double(mod(romOut+phit0,4096))/2048*pi),':r');
    plot(((i-1)*16:i*16), diffCode(i+2)*ones(1,17));
    phit0=mod(romOut(17)+phit0,4096);
    ylim([-1.2 1.2]);
end