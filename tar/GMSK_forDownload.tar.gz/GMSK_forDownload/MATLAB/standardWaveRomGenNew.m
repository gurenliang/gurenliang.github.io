clear all;
close all;

N=36; %the number of bits generated to simulate the gmsk modulation26
fs=13000000/12; dataRate=13000000/48;
samplePerBit=fs/dataRate;
d=[0 0 0 0 0 0    0 0 1 0 0 1 0 1 1 1 0 0 0 0 1 0 0 0 1 0 0 1 0 1 1 1    0 0 0 0];
alpha=1-2*(xor(d(2:N),d(1:N-1))); %size of alpha is 1*N-1

T=1/dataRate;
B=0.3/T;
syms t tao;

delta=sqrt(log(2))/(2*pi*B*T);
ht=exp(-t^2/(2*(delta*T)^2))/(delta*T*sqrt(2*pi));
%figure; ezplot(ht,[-3*T,3*T]); title('h(t)'); hold on; plot([-T,-T/2,T/2,T],subs(ht,t,[-T,-T/2,T/2,T]),'*');
gt=int(subs(ht,t,t-tao)/T,tao,-T/2,T/2);
pt=pi/2*int(subs(gt,t,tao),tao,-inf,t);
figure; ezplot(pt,[-3*T,3*T]); title('p(t)'); hold on; plot([-T/2,T/2],[0,0],'*');

figure(9); hold on;
%figure(10); hold on;
phy0=pi/6;
minVal=100; maxVal=-100;
for i=1:N-5
    weight=alpha(i:i+4);
    phyt=weight*(subs(pt,t,[t+2*T,t+T,t,t-T,t-2*T])');
    phyt=phyt-subs(phyt,t,-T/2)+phy0;
    phy0=subs(phyt,t,T/2);
    phytVal=subs(phyt,t,(-T/2+1/(2*fs):1/fs:T/2));
    
    
    %figure(9);
    subplot(2,1,1);hold on; %grid on;
    plot((i*T+T/2:1/fs:(i+1)*T+T/2),[alpha(i+2)*ones(size(i*T+T/2:1/fs:(i+1)*T+T/2-1/fs)),alpha(i+3)]);
    %subplot(2,1,2);hold on;
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),phytVal,'--r');
    
    %figure(10);
    subplot(2,1,2);hold on; %grid on;
    standardWaveRomCos((i-1)*4+1:i*4)=int8(cos(phytVal(1:4))*127);
    standardWaveRomSin((i-1)*4+1:i*4)=int8(sin(phytVal(1:4))*127);
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),cos(phytVal)); %title('I(t)');
    %subplot(2,1,2);hold on;
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),sin(phytVal),':r');
    
    minVal=min(min(phytVal),minVal); 
    maxVal=max(max(phytVal),maxVal);
end
cosRom=standardWaveRomCos(6*4+1:(N-9)*4);
sinRom=standardWaveRomSin(6*4+1:(N-9)*4);

figure(9);
subplot(2,1,1);
title('\alpha(n) and \phi(t)'); legend('differential signal', 'phase information');
minVal=min(-1.4,minVal); 
maxVal=max(+1.4,maxVal);
axis([T/2 (N-2)*T minVal-0.1 maxVal+0.1]);

subplot(2,1,2);
axis([T/2 (N-2)*T -1.5 1.5]);legend('I(t)','Q(t)');title('base band signal');

m=N;
N=54; %the number of bits generated to simulate the gmsk modulation 41
d=[0 0 0 0 0 0 0 0   0 1 0 0 1 0 1 1 0 1 1 1 1 1 1 1 1 0 0 1 1 0 0 1 1 0 1 0 1 0 1 0 0 0 1 1 1 1 0 0 0   0 0 0 0 0];
alpha=1-2*(xor(d(2:N),d(1:N-1))); %size of alpha is 1*N-1

figure(10); hold on;
phy0=pi/6;
minVal=100; maxVal=-100;
for i=1:N-5
    weight=alpha(i:i+4);
    phyt=weight*(subs(pt,t,[t+2*T,t+T,t,t-T,t-2*T])');
    phyt=phyt-subs(phyt,t,-T/2)+phy0;
    phy0=subs(phyt,t,T/2);
    phytVal=subs(phyt,t,(-T/2+1/2/fs:1/fs:T/2));
    
    subplot(2,1,1);hold on; %grid on;
    plot((i*T+T/2:1/fs:(i+1)*T+T/2),[alpha(i+2)*ones(size(i*T+T/2:1/fs:(i+1)*T+T/2-1/fs)),alpha(i+3)]);
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),phytVal,'--r');
    
    subplot(2,1,2);hold on; %grid on;
    standardWaveRomCos((i+m-6)*4+1:(i+m-5)*4)=int8(cos(phytVal(1:4))*127);
    standardWaveRomSin((i+m-6)*4+1:(i+m-5)*4)=int8(sin(phytVal(1:4))*127);
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),cos(phytVal)); %title('I(t)');
    plot((i*T+T/2+1/(2*fs):1/fs:(i+1)*T+T/2),sin(phytVal),':r');
    
    minVal=min(min(phytVal),minVal); 
    maxVal=max(max(phytVal),maxVal);
end
cosRom((m-11-4)*4+1:(m+N-24-9)*4)=standardWaveRomCos((m+3-4)*4+1:(N+m-19)*4);
sinRom((m-11-4)*4+1:(m+N-24-9)*4)=standardWaveRomSin((m+3-4)*4+1:(N+m-19)*4);
figure(10);
subplot(2,1,1);
title('\alpha(n) and \phi(t)'); legend('differential signal', 'phase information');
minVal=min(-1.4,minVal); 
maxVal=max(+1.4,maxVal);
axis([T/2 (N-2)*T minVal-0.1 maxVal+0.1]);

subplot(2,1,2);
axis([T/2 (N-2)*T -1.5 1.5]);legend('I(t)','Q(t)');title('base band signal');

figure;
subplot(2,1,1); hold on;
plot((1:(m-5)*4),standardWaveRomCos(1:(m-5)*4));
plot((1:(m-5)*4),standardWaveRomSin(1:(m-5)*4),':r');
subplot(2,1,2); hold on;
plot((1:(N-5)*4),standardWaveRomCos((m-5)*4+1:(m-5)*4+(N-5)*4));
plot((1:(N-5)*4),standardWaveRomSin((m-5)*4+1:(m-5)*4+(N-5)*4),':r');

figure; m=26; N=41;
subplot(2,1,1); hold on;
plot((1:(m-5)*4),cosRom(1:(m-5)*4));
plot((1:(m-5)*4),sinRom(1:(m-5)*4),':r');
subplot(2,1,2); hold on;
plot((1:(N-5)*4),cosRom((m-5)*4+1:(m-5)*4+(N-5)*4));
plot((1:(N-5)*4),sinRom((m-5)*4+1:(m-5)*4+(N-5)*4),':r');

standardWaveRomSin=standardWaveRomSin';
standardWaveRomCos=standardWaveRomCos';
cosRom=cosRom';
sinRom=sinRom';
%rom=int16(standardWaveRomCos)*256+int16(standardWaveRomSin);
