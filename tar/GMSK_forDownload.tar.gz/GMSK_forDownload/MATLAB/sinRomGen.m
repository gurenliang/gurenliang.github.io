clear all;
close all;

i=0:1023;
y=int32((sin(i*pi/2048)+1)*2047)';
plot([y,y(1024:-1:1),4094-y,4094-y(1024:-1:1)])