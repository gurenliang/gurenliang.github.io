clear all;
close all;

N=30; %the number of bits generated to simulate the gmsk modulation
fs=13000000; dataRate=1625000/6;
samplePerBit=fs/dataRate;
d=binornd(1,0.5,1,N+1);
alpha=1-2*(xor(d(1:N),d(2:N+1))); %size of alpha is 1*N

T=6/1625000;
B=0.3/T;
syms t tao;

delta=sqrt(log(2))/(2*pi*B*T);
ht=exp(-t^2/(2*(delta*T)^2))/(delta*T*sqrt(2*pi));
%figure; ezplot(ht,[-3*T,3*T]); title('h(t)'); hold on; plot([-T,-T/2,T/2,T],subs(ht,t,[-T,-T/2,T/2,T]),'*');
gt=int(subs(ht,t,t-tao)/T,tao,-T/2,T/2);
figure; 
ezplot(gt+subs(gt,t,t-T)+subs(gt,t,t+T)+subs(gt,t,t-2*T)+subs(gt,t,t+2*T)+subs(gt,t,t-3*T)+subs(gt,t,t+3*T)...
,[-6*T,6*T]); title('g(t)'); hold on; plot([-T/2,T/2],[0,0],'*');

pt=pi/2*int(subs(gt,t,tao),tao,-inf,t);
%figure; ezplot(pt,[-3*T,3*T]); title('p(t)'); hold on; plot([-T/2,T/2],[0,0],'*');

figure(9); hold on;
%figure(10); hold on;
phy0=0;
minVal=100; maxVal=-100;
phitTmp=zeros(1,samplePerBit+1);
phitTmp1=phitTmp;
for i=1:N-4
    weight=alpha(i:i+4);
    phyt=weight*(subs(pt,t,[t+2*T,t+T,t,t-T,t-2*T])');
    phyt=phyt-subs(phyt,t,-T/2)+phy0;
    phy0=subs(phyt,t,T/2);
    phytVal=subs(phyt,t,(-T/2:1/fs:T/2));
    
    
    figure(9);
    %subplot(3,1,1);
    hold on; 
    plot((i*T+T/2:1/fs:(i+1)*T+T/2),[alpha(i+2)*ones(size(i*T+T/2:1/fs:(i+1)*T+T/2-1/fs)),alpha(i+3)]);
    plot([i*T+T/2,(i+1)*T+T/2],[0,0],'*');
    %subplot(2,1,2);hold on;
    plot((i*T+T/2:1/fs:(i+1)*T+T/2),phytVal,'--r');
    plot((i*T:1/fs:(i+1)*T),sin(phytVal-phitTmp),'b:');
    plot((i*T-T/2:1/fs:(i+1)*T-T/2),(phytVal-phitTmp1),'g:');
    phitTmp1=phitTmp;
    phitTmp=phytVal;
    
    figure(10);
    subplot(2,1,1);hold on; %grid on;
    tofft((i-1)*48+1:i*48)=cos(phytVal(1:48));
    plot((i*T+T/2:1/fs:(i+1)*T+T/2-1/fs),cos(phytVal(1:48))); %title('I(t)');
    %subplot(2,1,2);hold on;
    plot((i*T+T/2:1/fs:(i+1)*T+T/2-1/fs),sin(phytVal(1:48)),':r');
    
    subplot(2,1,2);hold on; %grid on;
    received((i-1)*48+1:i*48)=cos(phytVal(1:48)+1)+j*sin(phytVal(1:48)+1);
    plot((i*T+T/2:1/fs:(i+1)*T+T/2-1/fs),cos(phytVal(1:48)+1)); %title('I(t)');
    %subplot(2,1,2);hold on;
    plot((i*T+T/2:1/fs:(i+1)*T+T/2-1/fs),sin(phytVal(1:48)+1),':r');
    
    minVal=min(min(phytVal),minVal); 
    maxVal=max(max(phytVal),maxVal);
end

figure(9);
%subplot(3,1,1);
title('\alpha(n) and \phi(t)'); legend('differential signal', 'phase information');
minVal=min(-1.4,minVal); 
maxVal=max(+1.4,maxVal);

% axis([T/2 (N-2)*T -2 2]);
% subplot(2,1,2);
axis([T/2 (N-2)*T minVal-0.1 maxVal+0.1]);

figure(10);
subplot(2,1,1);
% axis([T/2 (N-2)*T -2 2]);
%subplot(3,1,2);
axis([T/2 (N-2)*T -1.5 1.5]);legend('I(t)','Q(t)');title('base band signal');
subplot(2,1,2);
axis([T/2 (N-2)*T -1.5 1.5]);legend('I(t)','Q(t)');title('base band signal');

figure;
X=fft(tofft(1:(N-4)*48),(N-4)*48);
plot((1:(N-4)*48),log10(fftshift(abs(X))));

rt=received(1:12:(N-4)*48);
sample=tofft(7*48+1:12:18*48);
figure;
plot((3*T/2:12/fs:(N-3)*T+T/2-1/fs),rt);


