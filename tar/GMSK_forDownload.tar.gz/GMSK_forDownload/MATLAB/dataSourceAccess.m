dataSource(1:8)=[0, 0, 1, 1, 1, 0, 1, 0]';
dataSource(9:49)=[0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0]';
dataSource(50:85) = binornd(1,0.5,1,36);
dataSource(86:88)=zeros(1,3);
dataSource(89:156)=zeros(1,68);

fprintf('dataSourceAccess= \n');
for i=1:156
    fprintf('%u',dataSource(i));
    if(mod(i,39)==0) fprintf('\n'); end
end
fprintf('\n');