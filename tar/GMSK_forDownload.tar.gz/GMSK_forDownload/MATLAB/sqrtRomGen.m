clear all;
close all;

input=0:2^22-1;
outputRom=int16(sqrt(input))';
plot(input,outputRom);