clear all;
close all;
N=30; %the number of bits generated to simulate the gmsk modulation
fs=13000000; dataRate=1625000/6;
T=6/1625000;
B=0.3/T;
syms t tao;

delta=sqrt(log(2))/(2*pi*B*T);
ht=exp(-t^2/(2*(delta*T)^2))/(delta*T*sqrt(2*pi));
%figure; ezplot(ht,[-3*T,3*T]); title('h(t)'); hold on; plot([-T,-T/2,T/2,T],subs(ht,t,[-T,-T/2,T/2,T]),'*');
gt=int(subs(ht,t,t-tao)/T,tao,-T/2,T/2);
%figure; ezplot(gt,[-3*T,3*T]); title('g(t)'); hold on; plot([-T/2,T/2],[0,0],'*');

pt=pi/2*int(subs(gt,t,tao),tao,-inf,t);
%figure; ezplot(pt,[-3*T,3*T]); title('p(t)'); hold on;
%plot([-T/2,T/2],[0,0],'*');

for i=0:1:15
    diffCode(4:-1:1)=dec2binvec(i,4); diffCode(3:5)=[0,diffCode(3:4)];
    alpha = 1-2*diffCode;
    phyt=alpha*(subs(pt,t,[t+2*T,t+T,t,t-T,t-2*T])');
    phy0=subs(phyt,t,-T/2);
    %phiRom(i+1,:)=subs(phyt,t,(-7*T/16:T/16:T/2))-phy0;
    phiRom(i+1,:)=int32((subs(phyt,t,(-7*T/16:T/16:T/2))-phy0)*2048/pi);
end


