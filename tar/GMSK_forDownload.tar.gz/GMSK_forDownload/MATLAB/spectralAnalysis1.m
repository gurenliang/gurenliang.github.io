function [S] = spectralAnalysis1( data ,len,fs,f1,f2,idx)
%UNTITLED1 Summary of this function goes here
%  Detailed explanation goes here
s=data(:,2);
for i=3:12
    s=s*2+data(:,i);
end
s=s-data(:,1)*(2^11);
figure(f1);
subplot(2,1,idx);
plot([0:len-1]/fs,s([1:len]));
xlabel('time/s');
xlim([0 len]/fs);
S=abs(fftshift(fft(s,len)));
f=[-(len/2):len/2-1]*fs/len;
figure(f2);
subplot(2,1,idx);
plot(f,10*log10(S)); %the unit is KHz
xlabel('frequency (Hz)');
ylabel('Amptitude of spectral');
xlim([-fs/2 fs/2]);
ylim([0 70]);