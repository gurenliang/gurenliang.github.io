close all;
clear all;
dataSource(1:3)=zeros(1,3);
dataSource(4:61)  =binornd(1,0.5,1,58);
dataSource(62:87) = [0,0,1,0,0,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,0,1,0,1,1,1]';
dataSource(88:145)=binornd(1,0.5,1,58);
dataSource(146:148)=zeros(1,3);
dataSource(149:156)=zeros(1,8);

fprintf('dataSourceNormal= \n');
for i=1:156
    fprintf('%u',dataSource(i));
    if(mod(i,39)==0) 
        fprintf('\n'); 
    end
end
fprintf('\n');