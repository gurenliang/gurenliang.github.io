clear all;
close all;

N=32; nc=6;
hw(1:nc)=1;
hw(nc+1)=0.2;
hw(nc+2:N/2)=0;
hw(N:-1:N/2+1)=-hw(1:1:N/2);

hw=hw.*exp(-j*(N-1)/N*pi*(0:1:N-1));

hnRom=int16(real(ifft(hw))*1024)';
figure; stem(hnRom);
hn=double(hnRom)/1024;
figure; freqz(real(ifft(hw)));
figure; freqz(hn);
figure; plot(abs(fft(real(hn),3*N)));