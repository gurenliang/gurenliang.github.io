clear all;
close all;
N=30; %the number of bits generated to simulate the gmsk modulation
fs=13000000; dataRate=1625000/6;
T=6/1625000;
B=0.3/T;
syms t tao;

delta=sqrt(log(2))/(2*pi*B*T);
ht=exp(-t^2/(2*(delta*T)^2))/(delta*T*sqrt(2*pi));
%figure; ezplot(ht,[-3*T,3*T]); title('h(t)'); hold on; plot([-T,-T/2,T/2,T],subs(ht,t,[-T,-T/2,T/2,T]),'*');
gt=int(subs(ht,t,t-tao)/T,tao,-T/2,T/2);
%figure; ezplot(gt,[-3*T,3*T]); title('g(t)'); hold on; plot([-T/2,T/2],[0,0],'*');

pt=pi/2*int(subs(gt,t,tao),tao,-inf,t);
figure; ezplot(pt,[-3*T,3*T]); title('p(t)'); hold on;
plot([-T/2,T/2],[0,0],'*');


phyx=0;
for i=0:1:15
    diffCode(1:1:4)=dec2bin(i,4); 
    diffCode(1:1:4)=diffCode(1:1:4)-'0';
    diffCode(3:5)=[0,diffCode(3:4)];
    alpha = 1-2*diffCode;
    phyt=alpha(5:-1:1)*(subs(pt,t,[t+2*T,t+T,t,t-T,t-2*T])');
    
    phiRom(i+1,:)=subs(phyt,t,(-T/2:T/16:T/2));
    IQRom(i+1,:)=cos(phiRom(i+1,:));
    %figure; plot(phiRom(i+1,:)); hold on;
    %plot(IQRom(i+1,:));
end

IQRom=int16(IQRom*2046);
IQRom=IQRom';
figure(5); plot(phiRom');
figure(6); plot(IQRom);
